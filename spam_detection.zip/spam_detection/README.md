# AI Spam Shield

![AI Spam Shield](https://img.shields.io/badge/AI%20Spam%20Shield-v2.0.0-6c5ce7)
![Python](https://img.shields.io/badge/Python-3.8%2B-blue)
![FastAPI](https://img.shields.io/badge/FastAPI-0.105.0-green)
![Docker](https://img.shields.io/badge/Docker-Ready-blue)

An advanced spam detection system with machine learning, beautiful visualizations, and a modern UI.

![Screenshot Preview](app/static/img/screenshot.png)

## 🚀 Features

- 🧠 Machine learning-based text classification
- 📊 Advanced visualizations with Chart.js and D3.js
- 🔍 Detailed keyword analysis and explanation 
- ✨ Premium UI with animations and interactive elements
- 🔄 Real-time feedback system
- 🧩 Complete API for integration

## 🛠️ Quick Start

### Using Docker (Recommended)

```bash
# Build and run with Docker Compose
docker-compose up

# Or with Docker
docker build -t spam-detection-app .
docker run -p 8000:8000 spam-detection-app
```

### Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Run the application
python run.py
```

Access the application at: http://localhost:8000

## 📚 Documentation

For full documentation, see [documentation.md](documentation.md).

## 📋 API Reference

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/predict` | POST | Submit text for spam classification |
| `/api/feedback` | POST | Submit feedback on a classification |
| `/api/history` | GET | View classification history |
| `/api/stats` | GET | Get performance statistics |
| `/api/health` | GET | Check system health |
| `/docs` | GET | Interactive API documentation |

## 🔧 Technology Stack

- **Backend**: FastAPI (Python)
- **ML**: scikit-learn, NLTK
- **Frontend**: HTML, CSS, JavaScript, Bootstrap 5
- **Visualizations**: Chart.js, D3.js
- **Containerization**: Docker

## 🎨 UI Highlights

- **Interactive Dashboard**: Real-time statistics and performance metrics
- **Rich Visualizations**: Dynamic doughnut charts and word clouds
- **Smart Text Analysis**: Color-highlighted influential words
- **Adaptive Design**: Perfect experience on any device size
- **Micro-interactions**: Subtle animations for enhanced user engagement

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## ✨ Future Plans

- Enhanced model training with larger datasets
- Advanced analytics and reporting
- Email client integration plugins
- Multi-language support

---

Made with ❤️ for spam-free communication