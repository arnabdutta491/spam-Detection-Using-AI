from fastapi import FastAPI, Request, Form, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, JSONResponse
import uvicorn
from typing import List, Dict, Optional
import datetime
import re
import random

from app.models.spam_model import SpamDetector
from app.schemas.schemas import TextInput, PredictionResponse, HistoryResponse, FeedbackInput

# Initialize FastAPI app
app = FastAPI(
    title="AI Spam Shield",
    description="Advanced API for detecting spam in text messages using AI and machine learning",
    version="2.0.0"
)

# Initialize templates and static files
templates = Jinja2Templates(directory="app/templates")
app.mount("/static", StaticFiles(directory="app/static"), name="static")

# Initialize the spam detector model
spam_detector = SpamDetector()

# Store for message history (in-memory for demo)
message_history: List[Dict] = []

# Store for user feedback (in-memory for demo)
feedback_history: List[Dict] = []

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Render the home page with the spam detection form."""
    return templates.TemplateResponse("index.html", {"request": request, "result": None})

@app.post("/", response_class=HTMLResponse)
async def predict_form(request: Request, background_tasks: BackgroundTasks, text: str = Form(...)):
    """Handle form submission for spam detection."""
    prediction, probability, keywords = spam_detector.predict_with_keywords(text)
    
    # Format the prediction result
    result = {
        "text": text,
        "prediction": "Spam" if prediction == 1 else "Not Spam",
        "probability": f"{probability:.2f}%",
        "keywords": keywords
    }
    
    # Add to history in background to not delay response
    background_tasks.add_task(
        add_to_history, 
        text, 
        bool(prediction == 1), 
        float(probability)
    )
    
    return templates.TemplateResponse("index.html", {"request": request, "result": result})

@app.post("/api/predict", response_model=PredictionResponse)
async def predict_api(input_data: TextInput, background_tasks: BackgroundTasks):
    """API endpoint for spam detection."""
    prediction, probability, keywords = spam_detector.predict_with_keywords(input_data.text)
    
    # Add to history in background
    background_tasks.add_task(
        add_to_history, 
        input_data.text, 
        bool(prediction == 1), 
        float(probability)
    )
    
    return PredictionResponse(
        text=input_data.text,
        is_spam=bool(prediction == 1),
        spam_probability=float(probability),
        keywords=keywords
    )

@app.post("/api/feedback")
async def submit_feedback(feedback: FeedbackInput):
    """Submit user feedback on predictions."""
    feedback_history.append({
        "text": feedback.text,
        "prediction_correct": feedback.is_correct,
        "timestamp": datetime.datetime.now().isoformat()
    })
    
    return {"status": "success", "message": "Feedback received successfully"}

@app.get("/api/history", response_model=HistoryResponse)
async def get_history():
    """Get history of messages and their predictions."""
    spam_count = sum(1 for msg in message_history if msg["is_spam"])
    ham_count = len(message_history) - spam_count
    
    # Calculate average metrics
    avg_spam_prob = 0
    if spam_count > 0:
        avg_spam_prob = sum(msg["spam_probability"] for msg in message_history if msg["is_spam"]) / spam_count
    
    avg_ham_prob = 0
    if ham_count > 0:
        avg_ham_prob = sum(100 - msg["spam_probability"] for msg in message_history if not msg["is_spam"]) / ham_count
    
    return HistoryResponse(
        messages=message_history,
        spam_count=spam_count,
        ham_count=ham_count,
        avg_spam_probability=float(avg_spam_prob),
        avg_ham_probability=float(avg_ham_prob)
    )

@app.get("/api/stats")
async def get_stats():
    """Get aggregated statistics."""
    spam_count = sum(1 for msg in message_history if msg["is_spam"])
    ham_count = len(message_history) - spam_count
    total_count = len(message_history)
    
    # Calculate feedback stats
    correct_predictions = sum(1 for fb in feedback_history if fb["prediction_correct"])
    total_feedback = len(feedback_history)
    
    accuracy = 0
    if total_feedback > 0:
        accuracy = (correct_predictions / total_feedback) * 100
    
    return {
        "total_messages": total_count,
        "spam_count": spam_count,
        "ham_count": ham_count,
        "accuracy": float(accuracy),
        "avg_response_time_ms": random.randint(50, 200) # Mock response time for demonstration
    }

@app.get("/api/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "version": "2.0.0"}

def add_to_history(text: str, is_spam: bool, probability: float):
    """Add a message to the history store."""
    message_history.append({
        "text": text,
        "is_spam": is_spam,
        "spam_probability": probability,
        "timestamp": datetime.datetime.now().isoformat()
    })
    
    # Keep only the last 100 messages to avoid memory issues
    if len(message_history) > 100:
        message_history.pop(0)

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True) 