import os
import string
import pickle
import re
import nltk
import random
import numpy as np
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

class SpamDetector:
    """
    Spam detection model using NLP techniques and Multinomial Naive Bayes classifier.
    The model is trained to classify text messages as spam or not spam.
    """
    
    def __init__(self):
        """Initialize the spam detector model."""
        self.model_path = os.path.join(os.path.dirname(__file__), "spam_model.pkl")
        self.vectorizer_path = os.path.join(os.path.dirname(__file__), "vectorizer.pkl")
        
        # Download required NLTK data if not already downloaded
        try:
            nltk.data.find('tokenizers/punkt')
            nltk.data.find('corpora/stopwords')
            nltk.data.find('corpora/wordnet')
        except LookupError:
            nltk.download('punkt')
            nltk.download('stopwords')
            nltk.download('wordnet')
        
        self.stop_words = set(stopwords.words('english'))
        self.lemmatizer = WordNetLemmatizer()
        
        # Define spam indicator words for feature importance analysis
        self.spam_indicators = {
            'urgent': 0.8,
            'free': 0.7,
            'winner': 0.8,
            'cash': 0.6,
            'prize': 0.7,
            'claim': 0.6,
            'offer': 0.5,
            'congratulations': 0.7,
            'million': 0.6,
            'limited': 0.5,
            'click': 0.6,
            'link': 0.5,
            'verify': 0.4,
            'account': 0.3,
            'suspended': 0.7,
            'security': 0.3,
            'update': 0.3,
            'bank': 0.4,
            'credit': 0.5,
            'password': 0.7,
            'money': 0.6,
            'guaranteed': 0.8,
            'investment': 0.5
        }
        
        # Define ham (non-spam) indicator words
        self.ham_indicators = {
            'meeting': -0.6,
            'report': -0.5,
            'project': -0.6,
            'schedule': -0.5,
            'deadline': -0.4,
            'team': -0.7,
            'tomorrow': -0.3,
            'document': -0.5,
            'presentation': -0.6,
            'update': -0.3,
            'lunch': -0.6,
            'office': -0.5,
            'please': -0.3,
            'thanks': -0.7,
            'review': -0.5,
            'feedback': -0.6,
            'discuss': -0.5
        }
        
        if os.path.exists(self.model_path) and os.path.exists(self.vectorizer_path):
            self.model, self.vectorizer = self._load_model()
        else:
            self.model, self.vectorizer = self._train_model()
            self._save_model()
    
    def _preprocess_text(self, text):
        """
        Preprocess text by removing punctuation, stopwords, and lemmatizing.
        
        Args:
            text (str): The input text to preprocess
            
        Returns:
            str: Preprocessed text
        """
        # Convert to lowercase
        text = text.lower()
        
        # Remove punctuation
        text = text.translate(str.maketrans('', '', string.punctuation))
        
        # Tokenize
        tokens = nltk.word_tokenize(text)
        
        # Remove stopwords and lemmatize
        processed_tokens = [
            self.lemmatizer.lemmatize(token) 
            for token in tokens 
            if token not in self.stop_words and len(token) > 2
        ]
        
        # Join tokens back to string
        return ' '.join(processed_tokens)
    
    def _train_model(self):
        """
        Train a simple spam detection model.
        
        Returns:
            tuple: (Pipeline, TfidfVectorizer) - Trained model pipeline and vectorizer
        """
        # Enhanced training data with more examples
        spam_messages = [
            "Free bonus cash! Limited time offer",
            "Congratulations! You've won a free iPhone",
            "URGENT: Your account has been compromised",
            "Click here to claim your prize now",
            "Get 90% off today only!",
            "Congratulations! You have won a $1,000 Walmart gift card. Go to http://example.com to claim now",
            "URGENT: Your bank account has been suspended. Verify now",
            "You have been selected for a free cruise. Call now",
            "Your payment has been declined. Update your information immediately",
            "Final notice: Your account will be terminated",
            "Win a free vacation to Hawaii! Enter your details",
            "Limited time offer: 50% off luxury items. Click now",
            "Dear customer, your attention is required for an important security update",
            "You have been chosen to participate in an exclusive survey. $100 reward",
            "URGENT: Your package delivery has failed. Reschedule now",
            "You have won our monthly prize draw. Click to claim $500",
            "Your credit card has been charged $299. If this wasn't you, click here",
            "Investment opportunity: 300% returns guaranteed in 6 months",
            "Your PayPal account has been limited. Update your information now",
            "Free gift card! Complete this short survey to claim it",
            "You're eligible for a government grant. No repayment required"
        ]
        
        ham_messages = [
            "Meeting at 2pm in the conference room",
            "Please send me the report by tomorrow",
            "The project deadline is next Friday",
            "Let's have lunch together tomorrow",
            "I'll call you back in 10 minutes",
            "Thanks for sending the documents. I'll review them today",
            "Can you please confirm your attendance for the meeting?",
            "The office will be closed on Monday for the holiday",
            "I've reviewed your proposal and have some feedback",
            "Don't forget to submit your timesheet by Friday",
            "Your package will be delivered tomorrow between 1-3 PM",
            "The wifi password has been changed to 'office2023'",
            "Please remember to sign the contract before leaving",
            "I've shared the presentation slides with the team",
            "Your appointment is confirmed for Tuesday at 10 AM",
            "The client loved your proposal. Let's discuss next steps",
            "Can you review the budget spreadsheet I sent?",
            "Remember to bring your laptop to the team meeting",
            "I'll be working from home tomorrow. Available on Slack",
            "We need to reschedule our meeting to Friday at 3pm",
            "Please submit your expenses for the business trip"
        ]
        
        # Combine all messages and create labels
        messages = spam_messages + ham_messages
        labels = [1] * len(spam_messages) + [0] * len(ham_messages)
        
        # Shuffle the data while keeping messages and labels aligned
        combined = list(zip(messages, labels))
        random.shuffle(combined)
        messages, labels = zip(*combined)
        
        # Preprocess the training data
        processed_messages = [self._preprocess_text(msg) for msg in messages]
        
        # Create TF-IDF vectorizer
        vectorizer = TfidfVectorizer(max_features=1000)
        
        # Transform messages to feature vectors
        X = vectorizer.fit_transform(processed_messages)
        
        # Create and train Naive Bayes classifier
        classifier = MultinomialNB()
        classifier.fit(X, labels)
        
        # Create a pipeline with the vectorizer and classifier
        pipeline = Pipeline([
            ('vectorizer', vectorizer),
            ('classifier', classifier)
        ])
        
        return classifier, vectorizer
    
    def _save_model(self):
        """Save the trained model and vectorizer to disk."""
        os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
        with open(self.model_path, 'wb') as f:
            pickle.dump(self.model, f)
        with open(self.vectorizer_path, 'wb') as f:
            pickle.dump(self.vectorizer, f)
    
    def _load_model(self):
        """Load the model and vectorizer from disk."""
        with open(self.model_path, 'rb') as f:
            model = pickle.load(f)
        with open(self.vectorizer_path, 'rb') as f:
            vectorizer = pickle.load(f)
        return model, vectorizer
    
    def predict(self, text):
        """
        Predict whether the given text is spam or not.
        
        Args:
            text (str): The text to classify
            
        Returns:
            tuple: (prediction (0 or 1), spam probability percentage)
        """
        # Preprocess the input text
        processed_text = self._preprocess_text(text)
        
        # Transform text to feature vector
        X = self.vectorizer.transform([processed_text])
        
        # Make prediction
        prediction = self.model.predict(X)[0]
        
        # Get probability
        probability = self.model.predict_proba(X)[0][1] * 100
        
        # Convert numpy types to Python native types
        prediction = int(prediction)
        probability = float(probability)
        
        return prediction, probability
    
    def predict_with_keywords(self, text):
        """
        Predict with keyword analysis to explain the decision.
        
        Args:
            text (str): The text to classify
            
        Returns:
            tuple: (prediction (0 or 1), spam probability percentage, keywords list)
        """
        # Get basic prediction
        prediction, probability = self.predict(text)
        
        # Analyze keywords
        keywords = self._analyze_keywords(text)
        
        return prediction, probability, keywords
    
    def _analyze_keywords(self, text):
        """
        Analyze the text for keywords that indicate spam or ham.
        
        Args:
            text (str): The text to analyze
            
        Returns:
            list: List of dictionaries containing keyword analysis
        """
        # Preprocess and tokenize text
        text_lower = text.lower()
        # Clean special characters but keep spaces
        text_clean = re.sub(r'[^\w\s]', '', text_lower)
        words = text_clean.split()
        
        # Analyze each word
        keyword_results = []
        
        for word in set(words):
            # Skip short words
            if len(word) <= 2:
                continue
            
            # Check if it's a spam indicator
            if word in self.spam_indicators:
                score = self.spam_indicators[word]
                importance = int(score * 10)
                keyword_results.append({
                    "word": word,
                    "spam_score": score,
                    "importance": importance,
                    "type": "spam"
                })
            
            # Check if it's a ham indicator
            elif word in self.ham_indicators:
                score = self.ham_indicators[word]
                importance = int(abs(score) * 10)
                keyword_results.append({
                    "word": word,
                    "spam_score": score,
                    "importance": importance,
                    "type": "ham"
                })
        
        # Sort by absolute spam score
        keyword_results.sort(key=lambda x: abs(x["spam_score"]), reverse=True)
        
        # Limit to top 10 keywords
        return keyword_results[:10] 