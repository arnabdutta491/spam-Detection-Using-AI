// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Get all example buttons
    const exampleButtons = document.querySelectorAll('.example-btn');
    const textArea = document.getElementById('text');
    
    // Load stats from API
    fetchStats();
    
    // Add custom UI animations
    addEntryAnimations();
    
    // Add click event listeners to each example button
    exampleButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get the example text from the data-text attribute
            const exampleText = this.getAttribute('data-text');
            
            // Set the textarea value to the example text with typing effect
            typeText(textArea, exampleText);
            
            // Scroll to the textarea
            textArea.scrollIntoView({ behavior: 'smooth' });
            
            // Focus on the textarea
            textArea.focus();
            
            // Update character count
            updateCharCount();
        });
    });
    
    // Form validation and loading state
    const form = document.querySelector('form');
    if (form) {
        form.addEventListener('submit', function(event) {
            if (!textArea.value.trim()) {
                event.preventDefault();
                showToast('Please enter a message to check for spam.', 'warning');
            } else {
                // Add loading state with animation
                const submitButton = form.querySelector('button[type="submit"]');
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Analyzing...';
                submitButton.disabled = true;
                
                // Add shimmer effect to the form while processing
                form.classList.add('processing');
                
                // Start timing for response time tracking
                sessionStorage.setItem('startTime', Date.now());
            }
        });
    }
    
    // Reset form when clicking reset button
    const resetButton = document.getElementById('reset-form');
    if (resetButton) {
        resetButton.addEventListener('click', function() {
            // Clear with animation
            if (textArea.value) {
                textArea.classList.add('clearing');
                setTimeout(() => {
                    textArea.value = '';
                    textArea.classList.remove('clearing');
                    textArea.focus();
                    updateCharCount();
                }, 300);
            } else {
                textArea.focus();
            }
        });
    }
    
    // Real-time character count
    if (textArea) {
        const charCount = document.createElement('div');
        charCount.className = 'char-count text-muted mt-1';
        charCount.textContent = '0 characters';
        textArea.parentNode.insertBefore(charCount, textArea.nextSibling);
        
        textArea.addEventListener('input', updateCharCount);
        
        // Initialize character count
        updateCharCount();
        
        function updateCharCount() {
            const count = textArea.value.length;
            const oldCount = parseInt(charCount.getAttribute('data-count') || '0');
            charCount.setAttribute('data-count', count);
            
            // Animate the counter if it changed significantly
            if (Math.abs(count - oldCount) > 5) {
                charCount.classList.add('pulse');
                setTimeout(() => charCount.classList.remove('pulse'), 500);
            }
            
            charCount.textContent = count + (count === 1 ? ' character' : ' characters');
            
            // Change color based on length
            if (count > 300) {
                charCount.classList.add('text-success');
                charCount.classList.remove('text-muted', 'text-warning');
            } else if (count > 100) {
                charCount.classList.add('text-warning');
                charCount.classList.remove('text-muted', 'text-success');
            } else {
                charCount.classList.add('text-muted');
                charCount.classList.remove('text-warning', 'text-success');
            }
        }
    }
    
    // Generate text button (AI assisted text generation)
    const generateButton = document.getElementById('generate-text');
    if (generateButton) {
        generateButton.addEventListener('click', function() {
            // Examples of generated text (in a real app, this would call an API)
            const examples = [
                "Hey team, just a reminder that our weekly meeting is tomorrow at 3pm. Please prepare your updates.",
                "Please confirm your attendance for the upcoming conference call on Friday. We need to finalize the agenda.",
                "Your invoice #45678 has been processed. Payment will be sent within 3-5 business days.",
                "URGENT: Your account will be suspended in 24 hours. Click here to verify your information immediately!",
                "Congratulations! You've been selected to receive a free iPhone 15. Claim now before this offer expires!"
            ];
            
            // Select a random example
            const randomExample = examples[Math.floor(Math.random() * examples.length)];
            
            // Clear current text with nice animation if there's text
            if (textArea.value) {
                textArea.classList.add('clearing');
                setTimeout(() => {
                    textArea.value = '';
                    textArea.classList.remove('clearing');
                    // Type the new text
                    typeText(textArea, randomExample);
                }, 300);
            } else {
                // Type the text with animation
                typeText(textArea, randomExample);
            }
        });
    }
    
    // Feedback buttons
    const feedbackButtons = document.querySelectorAll('.feedback-btn');
    feedbackButtons.forEach(button => {
        button.addEventListener('click', function() {
            const value = this.getAttribute('data-value');
            const buttons = document.querySelectorAll('.feedback-btn');
            
            // Reset all buttons
            buttons.forEach(btn => btn.classList.remove('active'));
            
            // Activate current button with bounce animation
            this.classList.add('active', 'bounce');
            setTimeout(() => this.classList.remove('bounce'), 500);
            
            // TODO: Send feedback to backend
            console.log(`User feedback: ${value}`);
            
            // Show thank you message
            showToast('Thank you for your feedback! It helps improve our system.', 'success');
        });
    });
    
    // Calculate and show response time if coming back from a prediction
    if (sessionStorage.getItem('startTime')) {
        const startTime = sessionStorage.getItem('startTime');
        const endTime = Date.now();
        const responseTime = endTime - startTime;
        
        // Display in stats if element exists
        const responseTimeElement = document.getElementById('stats-response-time');
        if (responseTimeElement) {
            // Animate counting up
            animateNumber(responseTimeElement, 0, responseTime, 'ms');
        }
        
        // Clear the timing info
        sessionStorage.removeItem('startTime');
    }
});

// Add entry animations to elements
function addEntryAnimations() {
    // Add staggered animations to stats cards
    const statCards = document.querySelectorAll('.stat-card');
    statCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
        card.classList.add('fade-in-up');
    });
    
    // Add animations to main card
    const mainCard = document.querySelector('.card');
    if (mainCard) {
        mainCard.classList.add('fade-in');
    }
    
    // Add subtle hover effects to buttons
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(btn => {
        btn.addEventListener('mouseover', function() {
            this.classList.add('pulse');
            setTimeout(() => this.classList.remove('pulse'), 500);
        });
    });
}

// Type text with animation
function typeText(element, text, speed = 20) {
    element.value = '';
    element.focus();
    
    let i = 0;
    function type() {
        if (i < text.length) {
            element.value += text.charAt(i);
            i++;
            // Add randomness to typing speed for realistic effect
            setTimeout(type, speed + Math.random() * 30);
            updateCharCount();
        }
    }
    type();
}

// Animate number counting
function animateNumber(element, start, end, suffix = '') {
    const duration = 1000;
    const range = end - start;
    const minFps = 30;
    const increment = Math.abs(Math.floor(range / minFps / (duration / 1000)));
    
    let current = start;
    const timer = setInterval(function() {
        current += increment;
        if ((range > 0 && current >= end) || (range < 0 && current <= end)) {
            current = end;
            clearInterval(timer);
        }
        element.textContent = current + suffix;
    }, 1000 / minFps);
}

// Show toast notifications with enhanced styling
function showToast(message, type = 'info') {
    // Create toast container if it doesn't exist
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    // Create the toast element
    const toastEl = document.createElement('div');
    toastEl.className = `toast align-items-center text-white bg-${type} border-0`;
    toastEl.setAttribute('role', 'alert');
    toastEl.setAttribute('aria-live', 'assertive');
    toastEl.setAttribute('aria-atomic', 'true');
    
    // Add icon based on type
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'warning') icon = 'exclamation-triangle';
    if (type === 'danger') icon = 'exclamation-circle';
    
    const toastBody = document.createElement('div');
    toastBody.className = 'd-flex';
    
    toastBody.innerHTML = `
        <div class="toast-body">
            <i class="bi bi-${icon} me-2"></i>${message}
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    `;
    
    toastEl.appendChild(toastBody);
    toastContainer.appendChild(toastEl);
    
    // Add entry animation
    toastEl.classList.add('slide-in-right');
    
    // Initialize and show the toast
    const toast = new bootstrap.Toast(toastEl, { autohide: true, delay: 3000 });
    toast.show();
    
    // Remove the toast after it's hidden
    toastEl.addEventListener('hidden.bs.toast', function() {
        // Add exit animation then remove
        toastEl.classList.remove('slide-in-right');
        toastEl.classList.add('slide-out-right');
        setTimeout(() => toastEl.remove(), 500);
    });
}

// Fetch statistics from API with animations
async function fetchStats() {
    try {
        const response = await fetch('/api/history');
        if (response.ok) {
            const data = await response.json();
            
            // Update stats if elements exist
            const spamCountElement = document.getElementById('stats-spam-count');
            const hamCountElement = document.getElementById('stats-ham-count');
            const accuracyElement = document.getElementById('stats-accuracy');
            
            if (spamCountElement) {
                animateNumber(spamCountElement, 0, data.spam_count);
            }
            
            if (hamCountElement) {
                animateNumber(hamCountElement, 0, data.ham_count);
            }
            
            if (accuracyElement) {
                // Calculate mock accuracy (in a real app, this would come from the backend)
                const totalMessages = data.spam_count + data.ham_count;
                const accuracy = totalMessages > 0 ? 
                    Math.round(95 - (5 * Math.random())) : 0;
                animateNumber(accuracyElement, 0, accuracy, '%');
            }
        }
    } catch (error) {
        console.error('Error fetching stats:', error);
    }
} 