from pydantic import BaseModel, Field
from typing import List, Dict, Optional
import datetime

class TextInput(BaseModel):
    """Schema for text input to the spam detection API."""
    text: str = Field(..., 
                     description="The text message to be classified", 
                     examples=["Get a free iPhone now!", "Meeting at 2pm tomorrow"])

class PredictionResponse(BaseModel):
    """Schema for the prediction response from the spam detection API."""
    text: str = Field(..., description="The input text that was classified")
    is_spam: bool = Field(..., description="Whether the text is classified as spam")
    spam_probability: float = Field(..., 
                                   description="Probability (in percentage) that the text is spam", 
                                   ge=0, le=100)
    keywords: List[Dict] = Field([], description="Keywords that influenced the classification")

class MessageHistoryItem(BaseModel):
    """Schema for an item in the message history."""
    text: str
    is_spam: bool
    spam_probability: float
    timestamp: str

class HistoryResponse(BaseModel):
    """Schema for the history response from the API."""
    messages: List[Dict] = Field(..., description="List of message history items")
    spam_count: int = Field(..., description="Count of spam messages")
    ham_count: int = Field(..., description="Count of non-spam (ham) messages")
    avg_spam_probability: float = Field(0.0, description="Average spam probability for spam messages")
    avg_ham_probability: float = Field(0.0, description="Average ham probability for ham messages")

class FeedbackInput(BaseModel):
    """Schema for user feedback on predictions."""
    text: str = Field(..., description="The text that was classified")
    is_correct: bool = Field(..., description="Whether the prediction was correct")
    original_prediction: bool = Field(..., description="The original prediction (true for spam, false for ham)")

class KeywordAnalysis(BaseModel):
    """Schema for keyword analysis."""
    word: str = Field(..., description="The keyword found in the text")
    spam_score: float = Field(..., description="The contribution to spam score", ge=-1, le=1)
    importance: int = Field(..., description="Relative importance of the word", ge=1, le=10) 